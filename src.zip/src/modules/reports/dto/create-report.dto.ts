export class CreateReportDto {}
